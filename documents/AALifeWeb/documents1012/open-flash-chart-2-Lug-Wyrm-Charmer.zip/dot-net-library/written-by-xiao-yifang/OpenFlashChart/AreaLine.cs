using System;
using System.Collections.Generic;
using System.Text;

namespace OpenFlashChart
{
    [Obsolete("use Area instead")]
    public class AreaLine:AreaBase
    {
        public AreaLine()
        {
           // this.ChartType = "area_line";
        }
    }
}
