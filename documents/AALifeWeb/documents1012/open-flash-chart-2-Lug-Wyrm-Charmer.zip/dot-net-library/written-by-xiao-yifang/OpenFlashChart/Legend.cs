using System;
using System.Collections.Generic;
using System.Text;

namespace OpenFlashChart
{
    public class Legend:ChartElement
    {
        public Legend(string text)
        {
            base.Text = text;
        }

    }
}
