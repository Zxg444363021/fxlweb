using System;
using System.Collections.Generic;
using System.Text;

namespace OpenFlashChart
{
    public class Bar3D:BarBase
    {

        public Bar3D()
        {
            this.ChartType = "bar_3d";
        }
    }
}
